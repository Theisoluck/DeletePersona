const express = require('express');
const ProductoController = require('../controllers/producto.controller');
const router = express.Router();

// Obtener todos los productos
router.get('/', ProductoController.getAllProductos);
// Obtener un producto por su id
router.get('/:id', ProductoController.getProductoById);
// Obtener un producto por su numSerie
router.get('/numSerie/:numSerie', ProductoController.getProductoByNumSerie);
// Crear un producto
router.post('/', ProductoController.createProducto);

module.exports = router;
