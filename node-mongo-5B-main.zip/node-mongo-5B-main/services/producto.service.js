const ProductoRepository = require('../repositories/producto.repository');
const Validaciones = require('../utils/validation');

class ProductoService {
    async getAllProductos() {
        return await ProductoRepository.getAllProductos();
    }

    async getProductoById(id) {
        return await ProductoRepository.getProductoById(id);
    }

    async getProductoByNumSerie(numSerie) {
        return await ProductoRepository.getProductoByNumSerie(numSerie);
    }

    async createProducto(producto) {
        // validar los campos obligatorios
        if (!producto.nombre || !producto.precio || !producto.fechaAdquisicion || !producto.numSerie) {
            throw new Error('Nombre, numSerie, precio y stock son obligatorios');
        }

        // validar que el numSerie no exista
        const productoBynumSerie = await ProductoRepository.getProductoByNumSerie(producto.numSerie);
        if (productoBynumSerie) {
            throw new Error('El numSerie ya existe');
        }

        // Validar que el precio no sea negativo
        if (producto.precio < 1) {
            throw new Error('El precio no puede ser negativo');
        }

        // Validar que la fecha de adquisicion tenga formato valido
        if (!Validaciones.esFechaValida(producto.fechaAdquisicion)) {
            throw new Error('La fecha de adquisicion no tiene el formato correcto');
        }

        const yearAdquisicion = producto.fechaAdquisicion.split('-')[0];
        let countYear = await ProductoRepository.contarProductosByYear(yearAdquisicion);
        countYear++;
        producto.numInventario = `${yearAdquisicion}-${countYear.toString().padStart(3, '0')}`;
        return await ProductoRepository.CreateProducto(producto);
    }
}

module.exports = new ProductoService();
